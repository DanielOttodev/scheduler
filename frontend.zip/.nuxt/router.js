import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _469d0517 = () => interopDefault(import('..\\pages\\bookings.vue' /* webpackChunkName: "pages/bookings" */))
const _74a9072c = () => interopDefault(import('..\\pages\\businesspage.vue' /* webpackChunkName: "pages/businesspage" */))
const _3dbc08c8 = () => interopDefault(import('..\\pages\\customers.vue' /* webpackChunkName: "pages/customers" */))
const _6e67ba0d = () => interopDefault(import('..\\pages\\event.vue' /* webpackChunkName: "pages/event" */))
const _060e375c = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _175dbd00 = () => interopDefault(import('..\\pages\\settings.vue' /* webpackChunkName: "pages/settings" */))
const _339ba091 = () => interopDefault(import('..\\pages\\userProfile.vue' /* webpackChunkName: "pages/userProfile" */))
const _3c669445 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/bookings",
    component: _469d0517,
    name: "bookings"
  }, {
    path: "/businesspage",
    component: _74a9072c,
    name: "businesspage"
  }, {
    path: "/customers",
    component: _3dbc08c8,
    name: "customers"
  }, {
    path: "/event",
    component: _6e67ba0d,
    name: "event"
  }, {
    path: "/login",
    component: _060e375c,
    name: "login"
  }, {
    path: "/settings",
    component: _175dbd00,
    name: "settings"
  }, {
    path: "/userProfile",
    component: _339ba091,
    name: "userProfile"
  }, {
    path: "/",
    component: _3c669445,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}

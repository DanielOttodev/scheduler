# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<BusinessBookingsList>` | `<business-bookings-list>` (components/BusinessBookingsList.vue)
- `<BusinessClasses>` | `<business-classes>` (components/BusinessClasses.vue)
- `<BusinessLocation>` | `<business-location>` (components/BusinessLocation.vue)
- `<BusinessProfile>` | `<business-profile>` (components/BusinessProfile.vue)
- `<BusinessServices>` | `<business-services>` (components/BusinessServices.vue)
- `<Calendar>` | `<calendar>` (components/Calendar.vue)
- `<ClientHistory>` | `<client-history>` (components/ClientHistory.vue)
- `<ClientInfo>` | `<client-info>` (components/ClientInfo.vue)
- `<ClientNotes>` | `<client-notes>` (components/ClientNotes.vue)
- `<ClientProfile>` | `<client-profile>` (components/ClientProfile.vue)
- `<ClientProfileInfo>` | `<client-profile-info>` (components/ClientProfileInfo.vue)
- `<CreateClient>` | `<create-client>` (components/CreateClient.vue)
- `<EventTable>` | `<event-table>` (components/EventTable.vue)
- `<NewEventForm>` | `<new-event-form>` (components/NewEventForm.vue)
- `<NuxtLogo>` | `<nuxt-logo>` (components/NuxtLogo.vue)
- `<Register>` | `<register>` (components/Register.vue)
- `<ToastAlert>` | `<toast-alert>` (components/ToastAlert.vue)
- `<Tutorial>` | `<tutorial>` (components/Tutorial.vue)
- `<UserInfo>` | `<user-info>` (components/UserInfo.vue)
- `<VuetifyLogo>` | `<vuetify-logo>` (components/VuetifyLogo.vue)

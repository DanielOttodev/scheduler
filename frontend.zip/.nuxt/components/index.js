export { default as BusinessBookingsList } from '../..\\components\\BusinessBookingsList.vue'
export { default as BusinessClasses } from '../..\\components\\BusinessClasses.vue'
export { default as BusinessLocation } from '../..\\components\\BusinessLocation.vue'
export { default as BusinessProfile } from '../..\\components\\BusinessProfile.vue'
export { default as BusinessServices } from '../..\\components\\BusinessServices.vue'
export { default as Calendar } from '../..\\components\\Calendar.vue'
export { default as ClientHistory } from '../..\\components\\ClientHistory.vue'
export { default as ClientInfo } from '../..\\components\\ClientInfo.vue'
export { default as ClientNotes } from '../..\\components\\ClientNotes.vue'
export { default as ClientProfile } from '../..\\components\\ClientProfile.vue'
export { default as ClientProfileInfo } from '../..\\components\\ClientProfileInfo.vue'
export { default as CreateClient } from '../..\\components\\CreateClient.vue'
export { default as EventTable } from '../..\\components\\EventTable.vue'
export { default as NewEventForm } from '../..\\components\\NewEventForm.vue'
export { default as NuxtLogo } from '../..\\components\\NuxtLogo.vue'
export { default as Register } from '../..\\components\\Register.vue'
export { default as ToastAlert } from '../..\\components\\ToastAlert.vue'
export { default as Tutorial } from '../..\\components\\Tutorial.vue'
export { default as UserInfo } from '../..\\components\\UserInfo.vue'
export { default as VuetifyLogo } from '../..\\components\\VuetifyLogo.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}

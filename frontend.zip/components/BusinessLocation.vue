<template>
  <v-container>
    <v-row justify="center">
      <v-col>
        <h1 class="mb-3 text-center">Location</h1>
        <v-row justify="center">
          <v-card style="border-radius: 20px 150px 20px 150px">
            <iframe
              width="1200px"
              height="500"
              style="border: 0"
              loading="lazy"
              allowfullscreen
              referrerpolicy="no-referrer-when-downgrade"
              src="https://www.google.com/maps/embed/v1/place?key=AIzaSyDcUEY7i4DK2VgoLPb0kU19Oc3bewJAgqc&q=23+Bower+Way,Doreen+VIC"
            >
            </iframe>
          </v-card>
        </v-row>
      </v-col>
    </v-row>
  </v-container>
</template>
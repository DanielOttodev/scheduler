<template>
  <v-container>
    <v-row
      class="grey lighten-4"
      justify="center"
      align="center"
      style="width: 100vw"
    >
      <v-col cols="6">
        <h3 class="text-center">Personal Reformer</h3>
        <p class="text-center">60 minutes</p>
      </v-col>

      <v-col cols="6">
        <v-btn x-large class="ml-5 teal darken-3 white--text">Book</v-btn>
      </v-col>
    </v-row>
    <v-card>
      <v-row
        style="width: 100vw"
        class="grey lighten-5"
        justify="center"
        align="center"
      >
        <v-col cols="6">
          <h3 class="text-center">Clinical Pilates</h3>
          <p class="text-center">60 minutes</p>
        </v-col>

        <v-col cols="6">
          <v-btn x-large class="ml-5 teal darken-3 white--text">Book</v-btn>
        </v-col>
      </v-row>
    </v-card>
  </v-container>
</template>
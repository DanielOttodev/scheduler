<template>
  <v-row justify="center" align="center">
    <v-col cols="12" sm="8" md="6">
      <div class="text-center">
        <vuetify-logo />
      </div>
      <v-card>
        <v-card-title class="headline">
          Welcome {{ username }}, you are logged in!
        </v-card-title>
        <v-card-text>
          <p>
            Here are your user details, retrieved from the
            <a
              href="https://docs.aws.amazon.com/cognito/latest/developerguide/userinfo-endpoint.html"
              >/USERINFO</a
            >
            endpoint:
          </p>
          <template>
            <v-simple-table>
              <template v-slot:default>
                <thead>
                  <tr>
                    <th class="text-left">Property</th>
                    <th class="text-left">Value</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Email</td>
                    <td>{{ email }}</td>
                  </tr>
                  <tr>
                    <td>Phone number</td>
                    <td>{{ phoneNumber }}</td>
                  </tr>
                  <tr>
                    <td>UserId/sub</td>
                    <td>{{ userId }}</td>
                  </tr>
                  <tr>
                    <td>User name</td>
                    <td>{{ username }}</td>
                  </tr>
                  <tr>
                    <td>Access Token</td>
                    <td>{{ accessToken }}</td>
                  </tr>
                  <tr>
                    <td>Refresh Token</td>
                    <td>{{ refreshToken }}</td>
                  </tr>
                </tbody>
              </template>
            </v-simple-table>
          </template>
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn color="success" @click="checkAuth"> Check </v-btn>
          <v-btn color="primary" @click="logOut"> Log Out </v-btn>
        </v-card-actions>
      </v-card>
    </v-col>
  </v-row>
</template>

<script>
export default {
  layout: 'default',

  data() {
    return {
      email: null,
      phoneNumber: null,
      userId: null,
      username: null,
      accessToken: null,
      refreshToken: null,
    }
  },
  created() {
    this.email = this.$auth.user.email
    this.phoneNumber = this.$auth.user.phone_number
    this.userId = this.$auth.user.sub
    this.username = this.$auth.user.username
    this.accessToken = this.$auth.strategy.token.get()
    this.refreshToken = this.$auth.strategy.refreshToken.get()
  },
  methods: {
    logOut() {
      this.$auth.logout()
    },
    checkAuth() {
      //console.log(this.$auth.strategy.refreshToken.get())

      fetch(
        'http://zenlynodeapi-env.eba-pjmeubm4.ap-southeast-2.elasticbeanstalk.com/auth/validate',
        {
          headers: { Authorization: this.$auth.strategy.token.get() },
          method: 'GET',
        }
      )
        .then((response) => response.json())
        .then((x) => {
          if (x.status === 401) {
            alert('Session Expired')
            this.$auth.logout()
          }
        })
    },
  },
}
</script>
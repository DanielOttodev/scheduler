<template>
  <v-container>
    <v-row justify="center">
      <v-card>
        <v-img
          alt="profilepicture"
          position="center center"
          class="image"
          max-height="200"
          max-width="200px"
          src="https://avatars.githubusercontent.com/u/44077055?v=4"
        ></v-img>
      </v-card>
    </v-row>

    <v-row>
      <v-col>
        <UserInfo />
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {
  data: () => {
    return {}
  },
  created() {},
  methods: {},
}
</script>